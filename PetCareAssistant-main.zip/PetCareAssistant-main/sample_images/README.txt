Place sample images here and name them so they match breed aliases for filename-based matching.
Examples:
- golden_retriever.jpg
- german_shepherd.png
- persian_cat.jpg
- siamese_cat.png
