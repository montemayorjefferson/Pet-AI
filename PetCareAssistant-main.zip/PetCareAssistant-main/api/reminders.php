<?php
// api/reminders.php - simple JSON-backed reminders store

header('Content-Type: application/json');
$storePath = __DIR__ . '/../data/reminders.json';

// Ensure file exists
if (!file_exists($storePath)) {
  @file_put_contents($storePath, json_encode([]));
}

function read_store($path) {
  $raw = @file_get_contents($path);
  if ($raw === false || $raw === '') return [];
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

function write_store($path, $data) {
  $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
  return @file_put_contents($path, $json) !== false;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$items = read_store($storePath);

if ($method === 'GET') {
  echo json_encode($items);
  exit;
}

if ($method === 'POST') {
  $payload = json_decode(file_get_contents('php://input'), true);
  if (!is_array($payload)) $payload = [];
  $item = [
    'id' => uniqid('rem_', true),
    'breed' => $payload['breed'] ?? null,
    'type' => $payload['type'] ?? 'grooming',
    'frequency' => $payload['frequency'] ?? 'weekly',
    'created' => $payload['created'] ?? date('c')
  ];
  $items[] = $item;
  if (!write_store($storePath, $items)) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to write reminders.json (check permissions).']);
    exit;
  }
  echo json_encode($item);
  exit;
}

if ($method === 'DELETE') {
  $id = $_GET['id'] ?? null;
  if (!$id) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing id']);
    exit;
  }
  $before = count($items);
  $items = array_values(array_filter($items, function ($x) use ($id) { return ($x['id'] ?? '') !== $id; }));
  if ($before === count($items)) {
    http_response_code(404);
    echo json_encode(['error' => 'Not found']);
    exit;
  }
  if (!write_store($storePath, $items)) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to save']);
    exit;
  }
  echo json_encode(['ok' => true]);
  exit;
}

http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
