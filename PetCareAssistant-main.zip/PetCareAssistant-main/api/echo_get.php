<?php
header('Content-Type: application/json');
echo json_encode([
  'path' => $_SERVER['REQUEST_URI'] ?? '',
  'method' => $_SERVER['REQUEST_METHOD'] ?? '',
  'get' => $_GET
]);