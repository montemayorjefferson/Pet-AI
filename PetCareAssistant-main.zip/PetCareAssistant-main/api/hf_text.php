<?php
// api/hf_text.php - Proxy to Hugging Face text generation
// Accepts JSON: { "prompt": string, "max_new_tokens"?: number, "temperature"?: number, "model"?: string }

require_once __DIR__ . '/config.php';
header('Content-Type: application/json');

if (!$HF_API_KEY) {
  http_response_code(500);
  echo json_encode(['error' => 'HF_API_KEY not set on server']);
  exit;
}

// Support POST (JSON body) and GET (?prompt=...) to avoid server rules blocking POST
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'OPTIONS') { http_response_code(204); exit; }

// Build $prompt, $model, tokens, temp from either POST JSON or GET params
$prompt = '';
$model = $HF_TEXT_MODEL;
$max_new = 250;
$temp = 0.7;

if ($method === 'GET') {
  // Some servers/WAFs might block a parameter literally named "prompt"; allow alias "q"
  $prompt = isset($_GET['prompt']) ? (string)$_GET['prompt'] : (isset($_GET['q']) ? (string)$_GET['q'] : '');
  if (isset($_GET['model']) && $_GET['model'] !== '') $model = (string)$_GET['model'];
  if (isset($_GET['max_new_tokens'])) $max_new = (int)$_GET['max_new_tokens'];
  if (isset($_GET['temperature'])) $temp = (float)$_GET['temperature'];
} else if ($method === 'POST') {
  // Try JSON body first
  $raw = file_get_contents('php://input');
  $payload = json_decode($raw, true);
  if (!is_array($payload)) {
    $payload = [];
  }
  // Also accept form-encoded POST as a fallback
  if (!$payload && !empty($_POST)) {
    $payload = $_POST;
  }
  // Accept alias "q" for prompt
  $prompt = isset($payload['prompt']) ? (string)$payload['prompt'] : (isset($payload['q']) ? (string)$payload['q'] : '');
  if (isset($payload['model']) && $payload['model'] !== '') $model = (string)$payload['model'];
  if (isset($payload['max_new_tokens'])) $max_new = (int)$payload['max_new_tokens'];
  if (isset($payload['temperature'])) $temp = (float)$payload['temperature'];
} else {
  http_response_code(405);
  echo json_encode(['error' => 'Method not allowed']);
  exit;
}

if (trim($prompt) === '') {
  http_response_code(400);
  echo json_encode(['error' => 'Missing prompt', 'hint' => 'Provide ?q=... or ?prompt=... for GET, or JSON {"prompt":"..."} for POST.']);
  exit;
}

$body = [
  'inputs' => $prompt,
  'parameters' => [
    'max_new_tokens' => $max_new,
    'temperature' => $temp,
    'return_full_text' => false
  ],
  'options' => [
    'wait_for_model' => true
  ]
];

$url = "https://api-inference.huggingface.co/models/" . urlencode($model);
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  'Authorization: Bearer ' . $HF_API_KEY,
  'Accept: application/json',
  'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
curl_setopt($ch, CURLOPT_TIMEOUT, $HF_TIMEOUT);

$res = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err = curl_error($ch);
curl_close($ch);

if ($res === false) {
  http_response_code(502);
  echo json_encode(['error' => 'Curl error: ' . $err]);
  exit;
}

if ($httpcode >= 400) {
  http_response_code($httpcode);
  // Try to decode and bubble up message
  $errBody = json_decode($res, true);
  if (is_array($errBody)) {
    echo json_encode($errBody);
  } else {
    echo $res;
  }
  exit;
}

$data = json_decode($res, true);
if ($data === null) {
  // Not JSON? return raw
  echo $res;
  exit;
}

// Normalize common HF responses for text-generation
// Expected: [ { generated_text: "..." } ]
if (is_array($data) && isset($data[0]) && is_array($data[0]) && isset($data[0]['generated_text'])) {
  echo json_encode($data);
  exit;
}

// Some models return { error: ..., estimated_time: ... } etc.
if (isset($data['error'])) {
  http_response_code(502);
  echo json_encode($data);
  exit;
}

// Fallback: pass through
echo json_encode($data);
