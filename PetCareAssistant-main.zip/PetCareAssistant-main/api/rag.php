<?php
// api/rag.php - Simple vector search (MiniLM) over breeds.json with citations
// Query: GET /api/rag.php?q=care for husky&k=5
// Optional: POST {"q":"...","k":5}

require_once __DIR__ . '/config.php';
header('Content-Type: application/json');

// Check key
if (!$HF_API_KEY) {
  http_response_code(500);
  echo json_encode(['error' => 'HF_API_KEY not set on server']);
  exit;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
if ($method === 'OPTIONS') { http_response_code(204); exit; }

// Read input
$q = '';
$k = 5;
$embedModel = 'intfloat/e5-small-v2';
if ($method === 'GET') {
  $q = isset($_GET['q']) ? (string)$_GET['q'] : (isset($_GET['query']) ? (string)$_GET['query'] : '');
  if (isset($_GET['k'])) $k = max(1, (int)$_GET['k']);
  if (isset($_GET['model']) && $_GET['model'] !== '') $embedModel = (string)$_GET['model'];
} else if ($method === 'POST') {
  $raw = file_get_contents('php://input');
  $payload = json_decode($raw, true);
  if (!is_array($payload)) $payload = [];
  $q = isset($payload['q']) ? (string)$payload['q'] : (isset($payload['query']) ? (string)$payload['query'] : '');
  if (isset($payload['k'])) $k = max(1, (int)$payload['k']);
  if (isset($payload['model']) && $payload['model'] !== '') $embedModel = (string)$payload['model'];
} else {
  http_response_code(405);
  echo json_encode(['error' => 'Method not allowed']);
  exit;
}

if (trim($q) === '') {
  http_response_code(400);
  echo json_encode(['error' => 'Missing query', 'hint' => 'Provide ?q=... or POST {"q":"..."}']);
  exit;
}

$breedsPath = realpath(__DIR__ . '/../data/breeds.json');
if (!$breedsPath || !file_exists($breedsPath)) {
  http_response_code(500);
  echo json_encode(['error' => 'breeds.json not found']);
  exit;
}

$breeds = json_decode(file_get_contents($breedsPath), true);
if (!is_array($breeds)) $breeds = [];

// Build simple per-breed documents
$docs = [];
foreach ($breeds as $b) {
  $parts = [];
  $name = isset($b['name']) ? (string)$b['name'] : 'Unknown';
  $species = isset($b['species']) ? (string)$b['species'] : '';
  $parts[] = $name . ($species ? " (".$species.")" : '');
  foreach (['size','temperament','lifespan','exercise','grooming'] as $field) {
    if (isset($b[$field]) && $b[$field] !== '') $parts[] = ucfirst($field) . ': ' . (is_string($b[$field]) ? $b[$field] : json_encode($b[$field]));
  }
  if (isset($b['feeding_tips']) && is_array($b['feeding_tips'])) {
    $parts[] = 'Feeding tips: ' . implode('; ', $b['feeding_tips']);
  }
  if (isset($b['health']) && is_array($b['health'])) {
    $parts[] = 'Health: ' . implode('; ', $b['health']);
  }
  $text = implode("\n", $parts);
  $docs[] = [
    'id' => isset($b['id']) ? (string)$b['id'] : md5($name),
    'name' => $name,
    'species' => $species,
    'text' => $text,
  ];
}

// Embedding cache file tied to model name
$cachePath = realpath(__DIR__ . '/../data');
if (!$cachePath) { $cachePath = __DIR__ . '/../data'; }
$cacheFile = rtrim($cachePath, '/\\') . '/embeddings_' . preg_replace('/[^a-z0-9]+/i','_', $embedModel) . '.json';

// Load or compute doc embeddings
$docEmbeds = null;
$rebuild = true;
if (file_exists($cacheFile)) {
  $cached = json_decode(file_get_contents($cacheFile), true);
  if (is_array($cached) && isset($cached['model']) && $cached['model'] === $embedModel && isset($cached['source_mtime'])) {
    $srcMtime = filemtime($breedsPath) ?: 0;
    if ((int)$cached['source_mtime'] === (int)$srcMtime) {
      $docEmbeds = isset($cached['vectors']) && is_array($cached['vectors']) ? $cached['vectors'] : null;
      if ($docEmbeds) $rebuild = false;
    }
  }
}

if ($rebuild) {
  $docEmbeds = [];
  $embedErrors = [];
  foreach ($docs as $d) {
    $errInfo = null;
    $vec = hf_embed($d['text'], $embedModel, $HF_API_KEY, $HF_TIMEOUT, $errInfo);
    if (!$vec) { continue; }
    $docEmbeds[] = [
      'id' => $d['id'],
      'name' => $d['name'],
      'species' => $d['species'],
      'embedding' => $vec,
      'text' => $d['text'],
    ];
    // Be gentle with rate limits
    usleep(120000); // 120ms
  }
  $payload = [
    'model' => $embedModel,
    'source_mtime' => filemtime($breedsPath) ?: time(),
    'vectors' => $docEmbeds,
  ];
  @file_put_contents($cacheFile, json_encode($payload));
}

// Embed query
$errInfo = null;
$qVec = hf_embed($q, $embedModel, $HF_API_KEY, $HF_TIMEOUT, $errInfo);

// If HF is unavailable, fall back to keyword similarity so the endpoint still works in demos
$usedFallback = false;
if (!$qVec) {
  $usedFallback = true;
  $top = simple_keyword_search($docs, $q, $k);
} else {
  // Rank by cosine similarity
  $scored = [];
  foreach ($docEmbeds as $e) {
    if (!isset($e['embedding']) || !is_array($e['embedding'])) continue;
    $score = cosine($qVec, $e['embedding']);
    $scored[] = [
      'id' => $e['id'],
      'name' => $e['name'],
      'species' => $e['species'],
      'score' => $score,
      'text' => $e['text'],
      'citation' => [
        'title' => $e['name'] . ($e['species'] ? ' (' . $e['species'] . ')' : ''),
        'source' => 'breeds.json#' . $e['id']
      ]
    ];
  }
  usort($scored, function($a,$b){ return $a['score'] < $b['score'] ? 1 : -1; });
  $top = array_slice($scored, 0, $k);
}

echo json_encode([
  'query' => $q,
  'k' => $k,
  'model' => $embedModel,
  'results' => $top,
  'notes' => $usedFallback ? 'Used keyword fallback due to embedding error' : null,
  'error' => $usedFallback ? $errInfo : null
]);
exit;

// --- Helpers ---
function hf_embed($text, $model, $apiKey, $timeout, &$errInfo = null) {
  // Prefer /models; some orgs route feature extraction under /models only
  $url = 'https://api-inference.huggingface.co/models/' . urlencode($model);
  $body = [
    'inputs' => (string)$text,
    'options' => [ 'wait_for_model' => true ]
  ];

  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Authorization: Bearer ' . $apiKey,
    'Accept: application/json',
    'Content-Type: application/json'
  ]);
  curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
  curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
  $res = curl_exec($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  $err = curl_error($ch);
  curl_close($ch);

  if ($res === false || $code >= 400) {
    $errInfo = $res ? $res : ('curl_error:' . $err);
    return null;
  }
  $data = json_decode($res, true);
  // Response may be [dims] or [tokens][dims]
  if (is_array($data) && !empty($data)) {
    if (isset($data[0]) && is_array($data[0]) && isset($data[0][0]) && is_numeric($data[0][0])) {
      // token embeddings -> mean pool
      $numTokens = count($data);
      $dims = count($data[0]);
      $mean = array_fill(0, $dims, 0.0);
      foreach ($data as $t) {
        for ($i=0; $i<$dims; $i++) { $mean[$i] += (float)$t[$i]; }
      }
      for ($i=0; $i<$dims; $i++) { $mean[$i] /= max(1, $numTokens); }
      return $mean;
    }
    if (isset($data[0]) && is_numeric($data[0])) {
      return array_map('floatval', $data);
    }
  }
  return null;
}

function cosine($a, $b) {
  $dot = 0.0; $na = 0.0; $nb = 0.0;
  $len = min(count($a), count($b));
  if ($len === 0) return 0.0;
  for ($i=0; $i<$len; $i++) {
    $ai = (float)$a[$i];
    $bi = (float)$b[$i];
    $dot += $ai * $bi; $na += $ai*$ai; $nb += $bi*$bi;
  }
  $den = sqrt($na) * sqrt($nb);
  return $den > 0 ? $dot / $den : 0.0;
}

function simple_keyword_search($docs, $q, $k) {
  $qTokens = tokenize($q);
  $scored = [];
  foreach ($docs as $d) {
    $dTokens = tokenize($d['text']);
    if (!$dTokens) continue;
    $overlap = count(array_intersect_key($dTokens, $qTokens));
    $score = $overlap / max(1, count($qTokens));
    $scored[] = [
      'id' => $d['id'],
      'name' => $d['name'],
      'species' => $d['species'],
      'score' => $score,
      'text' => $d['text'],
      'citation' => [
        'title' => $d['name'] . ($d['species'] ? ' (' . $d['species'] . ')' : ''),
        'source' => 'breeds.json#' . $d['id']
      ]
    ];
  }
  usort($scored, function($a,$b){ return $a['score'] < $b['score'] ? 1 : -1; });
  return array_slice($scored, 0, $k);
}

function tokenize($text) {
  $text = strtolower((string)$text);
  $text = preg_replace('/[^a-z0-9\s]+/i', ' ', $text);
  $parts = preg_split('/\s+/', trim($text));
  $map = [];
  foreach ($parts as $p) { if ($p !== '') $map[$p] = true; }
  return $map;
}


