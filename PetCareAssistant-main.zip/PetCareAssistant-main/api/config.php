<?php
// api/config.php - configuration for external services
// Set your Hugging Face API key in an environment variable HF_API_KEY
// For Windows/XAMPP, you can set it in Apache envvars or use a local .htaccess with SetEnv, or hardcode here (not recommended).

// Prefer environment variable
$HF_API_KEY = getenv('HF_API_KEY');
if (!$HF_API_KEY || $HF_API_KEY === '') {
  // As a last resort, you can set a placeholder here. Do NOT commit real keys.
  $HF_API_KEY = '';
}

// Default models (you may change to any model you have access to)
$HF_IMAGE_MODEL = 'google/vit-base-patch16-224'; // image-classification
// Use a widely available public instruction-tuned model to avoid 404s from HF
// Examples that generally work without gated access:
// - 'HuggingFaceH4/zephyr-7b-beta'
// - 'mistralai/Mistral-7B-Instruct-v0.2'
// If you have access to others, feel free to change.
$HF_TEXT_MODEL  = 'HuggingFaceH4/zephyr-7b-beta'; // text-generation

// Timeout seconds for outbound calls
$HF_TIMEOUT = 30;
