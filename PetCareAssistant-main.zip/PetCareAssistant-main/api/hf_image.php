<?php
// api/hf_image.php - Proxy to Hugging Face image classification
// Accepts multipart/form-data with field 'image'

require_once __DIR__ . '/config.php';
header('Content-Type: application/json');

if (!$HF_API_KEY) {
  http_response_code(500);
  echo json_encode(['error' => 'HF_API_KEY not set on server']);
  exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  http_response_code(405);
  echo json_encode(['error' => 'Method not allowed']);
  exit;
}

if (!isset($_FILES['image']) || !is_uploaded_file($_FILES['image']['tmp_name'])) {
  http_response_code(400);
  echo json_encode(['error' => 'No image uploaded']);
  exit;
}

$imgPath = $_FILES['image']['tmp_name'];
$imgData = @file_get_contents($imgPath);
if ($imgData === false) {
  http_response_code(400);
  echo json_encode(['error' => 'Failed to read image']);
  exit;
}

$model = isset($_GET['model']) && $_GET['model'] !== '' ? $_GET['model'] : $HF_IMAGE_MODEL;
$url = "https://api-inference.huggingface.co/models/" . urlencode($model);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $imgData);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
  'Authorization: Bearer ' . $HF_API_KEY,
  'Accept: application/json',
  'Content-Type: application/octet-stream'
]);
curl_setopt($ch, CURLOPT_TIMEOUT, $HF_TIMEOUT);

$res = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$err = curl_error($ch);
curl_close($ch);

if ($res === false) {
  http_response_code(502);
  echo json_encode(['error' => 'Curl error: ' . $err]);
  exit;
}

if ($httpcode >= 400) {
  http_response_code($httpcode);
  echo $res;
  exit;
}

// Expected response: array of arrays with label/score or nested arrays depending on model
$data = json_decode($res, true);
if ($data === null) {
  echo $res; // pass-through
  exit;
}

echo json_encode($data);
