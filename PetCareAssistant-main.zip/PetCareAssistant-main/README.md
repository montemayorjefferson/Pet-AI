# PetCareAssistant — Setup & Usage Guide

A lightweight PHP app to identify pet breeds and provide care recommendations. Works offline from local data and optionally connects to Hugging Face for AI features.

## Features
- Identify a breed by dropdown or filename-based matching of an uploaded image
- Show feeding, grooming, exercise, and health tips from `data/breeds.json`
- Nutrition calculator (RER × life‑stage multiplier)
- Grooming/exercise reminders stored in `data/reminders.json`
- Optional AI via Hugging Face Inference API:
  - Image classification proxy
  - Text generation proxy
  - Simple RAG (vector search) over local data with embedding cache

## Project Structure
- `index.php` — main UI
- `assets/css/styles.css`, `assets/js/main.js` — styles and client logic
- `data/` — local knowledge and stores
  - `breeds.json` — breed knowledge base
  - `reminders.json` — reminders store (auto-created)
  - `embeddings_*.json` — RAG cache (auto-created)
- `api/` — PHP endpoints
  - `config.php` — models, timeouts, and `HF_API_KEY` lookup
  - `hf_image.php` — image classify (HF proxy)
  - `hf_text.php` — text generation (HF proxy)
  - `rag.php` — vector search over `breeds.json` (uses HF embeddings with fallback)
  - `reminders.php` — JSON CRUD for reminders
  - `echo_get.php` — debug endpoint
- `flow.html` — architecture and request flow overview
- `sample_images/` — put sample images for filename matching

## Requirements
- PHP 8.0+ (XAMPP on Windows works well)
- PHP cURL and OpenSSL extensions enabled
- Internet only required for AI features (Hugging Face)

## Quick Start (Windows/XAMPP)
1. Install XAMPP and start Apache.
2. Place this folder at `C:\xampp\htdocs\PetCareAssistant`.
3. Visit `http://localhost/PetCareAssistant/`.
4. Local features work without the internet. To enable AI features, set `HF_API_KEY` (below).

## Configure Hugging Face
`api/config.php` reads your key from the `HF_API_KEY` environment variable.
Pick ONE method:

- .htaccess (per directory)
  - Ensure `AllowOverride All` is enabled for `htdocs`.
  - Create `.htaccess` in the project root or `api/` with:
    
    SetEnv HF_API_KEY "hf_xxx_your_key"

- Tip: To avoid committing secrets, copy `.htaccess.example` to `.htaccess` and set your key. The repository `.gitignore` excludes `.htaccess`, `data/reminders.json`, and `data/embeddings_*.json`.

- Apache config (global or vhost)
  - Add inside `<Directory "C:/xampp/htdocs">` or your vhost and restart Apache:
    
    SetEnv HF_API_KEY "hf_xxx_your_key"

- Hardcode (not recommended)
  - Edit `api/config.php` and set `$HF_API_KEY = 'hf_xxx_your_key';`.

Default models (editable in `api/config.php`):
- Image: `google/vit-base-patch16-224`
- Text: `HuggingFaceH4/zephyr-7b-beta`
- Embeddings: `intfloat/e5-small-v2`

## Using the App
- Identify a breed via dropdown, or upload an image named like a breed/alias (e.g., `golden_retriever.jpg`).
- Read care info sections and use the nutrition calculator.
- After a breed is selected, add reminders (stored in `data/reminders.json`).
- Click “AI Identify” to use the image model (requires `HF_API_KEY`).

## API Endpoints
- GET `api/reminders.php` — list reminders
- POST `api/reminders.php` — create reminder
  - JSON body: `{ "breed": string, "type": "grooming"|"exercise", "frequency": "daily|weekly|biweekly|monthly", "created": ISO8601 }`
- DELETE `api/reminders.php?id=REM_ID` — delete reminder

- GET `api/rag.php?q=your+query&k=5` — search breed docs; requires `HF_API_KEY` for embeddings, falls back to keywords if unavailable

- GET `api/hf_text.php?q=hello` or POST JSON `{ "prompt": "hello" }` — text generation proxy

- POST `api/hf_image.php` (multipart form-data with field `image`) — image classification proxy

### Curl Examples (adjust path as needed)
```bash
# RAG
curl "http://localhost/PetCareAssistant/api/rag.php?q=grooming%20for%20poodle&k=3"

# Text (GET)
curl "http://localhost/PetCareAssistant/api/hf_text.php?q=hello"

# Text (POST JSON)
curl -X POST -H "Content-Type: application/json" \
  -d '{"prompt":"tips for husky care"}' \
  "http://localhost/PetCareAssistant/api/hf_text.php"

# Image (multipart)
curl -X POST -F image=@sample_images/golden_retriever.jpg \
  "http://localhost/PetCareAssistant/api/hf_image.php"

# Reminders (create)
curl -X POST -H "Content-Type: application/json" \
  -d '{"breed":"Siberian Husky","type":"exercise","frequency":"weekly","created":"2025-01-01T12:00:00Z"}' \
  "http://localhost/PetCareAssistant/api/reminders.php"
```

## Data & Caching
- `data/reminders.json` is created on first use. Ensure Apache/PHP can write to `data/`.
- RAG caches embeddings under `data/embeddings_<model>.json` bound to the `breeds.json` mtime.
- Editing `data/breeds.json` will trigger cache regeneration on next `rag.php` call.

## Security Notes
- Keep `HF_API_KEY` secret; prefer env variables over hardcoding.
- Uploaded images are not stored; they are proxied in-memory to HF.
- This demo is file-backed; for production, add auth, rate limiting, input validation, and persistent storage.

## Troubleshooting
- 500 “HF_API_KEY not set”: configure via `.htaccess` or Apache config.
- 502 cURL errors: check internet, model availability, and PHP cURL/OpenSSL.
- Permission denied for `data/*.json`: grant write access to the `data/` folder.
- HF 404/401: verify model names in `api/config.php` and your key’s access.

## Dev Tips
- Static assets are cache-busted via `?v=<mtime>` in `index.php`.
- See `flow.html` for an architecture overview.
- Add breeds by appending to `data/breeds.json` (include `aliases` for better matching).

## License
Provided as-is for educational/demo use. Add a license before distribution.
