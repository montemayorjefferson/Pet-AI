<?php
// index.php - Pet Breed Identifier & Care Recommender (Offline)
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>PetCareAI • Identify & Care</title>
  <!-- Optional Bootstrap CDN (remove if strictly offline) -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/styles.css?v=<?= htmlspecialchars(@filemtime(__DIR__ . '/assets/css/styles.css') ?: time(), ENT_QUOTES) ?>" />
</head>
<body>
  <!-- Navbar --> 
  <nav class="navbar navbar-expand-lg site-navbar navbar-light">
    <div class="container">
      <a class="navbar-brand fw-bold" href="#">🐾 PetCareAI</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain" aria-controls="navMain" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navMain">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
          <li class="nav-item"><a class="nav-link active" href="#">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="#identify">Identify</a></li>
          <li class="nav-item"><a class="nav-link" href="#care">Care</a></li>
          <li class="nav-item"><a class="nav-link" href="#schedule">Schedule</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Hero -->
  <section class="hero">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-8">
          <h1 class="hero-title mb-2">Find your pet's breed and care like a pro</h1>
          <p class="hero-subtitle mb-0">Upload a photo or pick a breed. Get feeding, grooming, health, and daily routine tips instantly.</p>
        </div>
      </div>
    </div>
  </section>

  <div class="container py-4">
<!-- Step 1: Upload/select breed -->
<div class="card mb-4" id="identify">
  <div class="card-header">1) Identify Breed</div>
  <div class="card-body">
    <div class="row g-3 align-items-end">

      <!-- Select Breed -->
      <div class="col-md-4">
        <label for="breedSelect" class="form-label">Select Breed</label>
        <select id="breedSelect" class="form-select">
          <option value="">-- Choose a breed --</option>
        </select>
        <div class="form-text text-muted">Or pick from known breeds</div>
      </div>

      <!-- Upload Image -->
      <div class="col-md-4">
        <label for="imageInput" class="form-label">Or upload an image</label>
        <input type="file" id="imageInput" accept="image/*" class="form-control" />
        <div class="form-text text-muted">Filename-based matching (e.g., golden_retriever.jpg)</div>
      </div>

      <!-- Buttons -->
      <div class="col-md-4 d-grid gap-2">
        <button id="identifyBtn" class="btn btn-primary">Identify</button>
        <button id="aiIdentifyBtn" class="btn btn-outline-primary">AI Identify (Hugging Face)</button>
        <div id="aiIdentifyStatus" class="form-text text-muted"></div>
      </div>

    </div>
  </div>
</div>


    <!-- Step 2: Show output -->
    <div class="card mb-4" id="care">
      <div class="card-header">2) Breed Information & Care</div>
      <div class="card-body" id="resultSection">
        <div id="breedSummary" class="mb-3"></div>
        <div class="row g-3">
          <div class="col-md-6">
            <div class="p-3 bg-light rounded h-100">
              <h5>Feeding & Nutrition</h5>
              <div id="feedingTips"></div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="p-3 bg-light rounded h-100">
              <h5>Grooming & Exercise</h5>
              <div id="groomingExercise"></div>
            </div>
          </div>
        </div>
        <div class="mt-3">
          <h5>Health Tips</h5>
          <div id="healthTips"></div>
        </div>
        <hr />
        <div class="mt-3">
          <h5>AI Care Recommendations</h5>
          <div class="mt-2" id="aiAdvice"></div>
        </div>
      </div>
    </div>

    <!-- Step 3: Nutrition Calculator -->
    <div class="card mb-4">
      <div class="card-header">3) Pet Nutrition Calculator</div>
      <div class="card-body">
        <div class="row g-3 align-items-end">
          <div class="col-sm-4">
            <label for="petWeight" class="form-label">Weight (kg)</label>
            <input type="number" step="0.1" min="0" id="petWeight" class="form-control" placeholder="e.g., 30" />
          </div>
          <div class="col-sm-4">
            <label for="lifeStage" class="form-label">Life Stage</label>
            <select id="lifeStage" class="form-select">
              <option value="adult">Adult</option>
              <option value="puppy">Puppy</option>
              <option value="kitten">Kitten</option>
              <option value="senior">Senior</option>
            </select>
          </div>
          <div class="col-sm-4">
            <button id="calcCaloriesBtn" class="btn btn-secondary w-100">Calculate Calories</button>
          </div>
        </div>
        <div class="mt-3" id="calorieResult"></div>
      </div>
    </div>

    <!-- Step 4: Grooming & Exercise Scheduler -->
    <div class="card mb-4" id="schedule">
      <div class="card-header">4) Grooming & Exercise Scheduler</div>
      <div class="card-body">
        <div class="row g-3 align-items-end">
          <div class="col-md-4">
            <label for="reminderType" class="form-label">Type</label>
            <select id="reminderType" class="form-select">
              <option value="grooming">Grooming</option>
              <option value="exercise">Exercise</option>
            </select>
          </div>
          <div class="col-md-4">
            <label for="reminderFrequency" class="form-label">Frequency</label>
            <select id="reminderFrequency" class="form-select">
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="biweekly">Biweekly</option>
              <option value="monthly">Monthly</option>
            </select>
          </div>
          <div class="col-md-4">
            <button id="addReminderBtn" class="btn btn-success w-100">Add Reminder</button>
          </div>
        </div>

        <div class="table-responsive mt-3">
          <table class="table table-striped align-middle" id="remindersTable">
            <thead>
              <tr>
                <th>Breed</th>
                <th>Type</th>
                <th>Frequency</th>
                <th>Created</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
      </div>
    </div>

    <footer class="text-center text-muted small">Designed with 🐾 for pets. © 2025 PetCareAI</footer>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <?php
    // Cache-bust the main.js to avoid stale client code after updates
    $mainJsPath = __DIR__ . '/assets/js/main.js';
    $ver = file_exists($mainJsPath) ? (string)filemtime($mainJsPath) : (string)time();
  ?>
  <script src="assets/js/main.js?v=<?= htmlspecialchars($ver, ENT_QUOTES) ?>"></script>
</body>
</html>
