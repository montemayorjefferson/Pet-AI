(function () {
  const breedsUrl = './data/breeds.json';
  const remindersApi = './api/reminders.php';

  // UI elements
  const breedSelect = document.getElementById('breedSelect');
  const imageInput = document.getElementById('imageInput');
  const identifyBtn = document.getElementById('identifyBtn');
  const aiIdentifyBtn = document.getElementById('aiIdentifyBtn');
  const aiIdentifyStatus = document.getElementById('aiIdentifyStatus');
  const breedSummary = document.getElementById('breedSummary');
  const feedingTips = document.getElementById('feedingTips');
  const groomingExercise = document.getElementById('groomingExercise');
  const healthTips = document.getElementById('healthTips');
  const aiQuestion = document.getElementById('aiQuestion');
  const askAiBtn = document.getElementById('askAiBtn');
  const aiAdvice = document.getElementById('aiAdvice');
  const aiTextStatus = document.getElementById('aiTextStatus');

  const petWeight = document.getElementById('petWeight');
  const lifeStage = document.getElementById('lifeStage');
  const calcCaloriesBtn = document.getElementById('calcCaloriesBtn');
  const calorieResult = document.getElementById('calorieResult');

  const reminderType = document.getElementById('reminderType');
  const reminderFrequency = document.getElementById('reminderFrequency');
  const addReminderBtn = document.getElementById('addReminderBtn');
  const remindersTableBody = document.querySelector('#remindersTable tbody');

  let BREEDS = [];
  let selectedBreed = null;

  async function loadBreeds() {
    try {
      const res = await fetch(`${breedsUrl}?v=${Date.now()}`, { cache: 'no-store' });
      BREEDS = await res.json();
      populateBreedDropdown(BREEDS);
    } catch (e) {
      console.error('Failed to load breeds.json', e);
    }
  }

  function populateBreedDropdown(list) {
    // Keep the first placeholder option, clear the rest
    while (breedSelect.options.length > 1) {
      breedSelect.remove(1);
    }
    // Group by species for clearer browsing
    const speciesToBreeds = list.reduce((acc, b) => {
      const key = (b.species || 'Other').toString();
      (acc[key] ||= []).push(b);
      return acc;
    }, {});
    const preferredOrder = ['Dog', 'Cat'];
    const allSpecies = [
      ...preferredOrder.filter(s => speciesToBreeds[s]),
      ...Object.keys(speciesToBreeds).filter(s => !preferredOrder.includes(s))
    ];
    allSpecies.forEach(species => {
      const group = document.createElement('optgroup');
      group.label = species;
      (speciesToBreeds[species] || [])
        .sort((a, b) => a.name.localeCompare(b.name))
        .forEach(b => {
          const opt = document.createElement('option');
          opt.value = b.id;
          opt.textContent = b.name;
          group.appendChild(opt);
        });
      if (group.childElementCount > 0) breedSelect.appendChild(group);
    });
  }

  function matchBreedFromFilename(filename) {
    if (!filename) return null;
    const base = filename.toLowerCase();
    for (const b of BREEDS) {
      const candidates = [b.name, ...(b.aliases || [])].map(x => x.toLowerCase().replace(/\s+/g, '_'));
      for (const c of candidates) {
        if (base.includes(c)) return b;
      }
    }
    return null;
  }

  function renderBreed(b) {
    if (!b) {
      breedSummary.innerHTML = '<div class="text-danger">No breed identified. Please select from the dropdown.</div>';
      feedingTips.innerHTML = '';
      groomingExercise.innerHTML = '';
      healthTips.innerHTML = '';
      aiAdvice.innerHTML = '';
      selectedBreed = null;
      return;
    }
    selectedBreed = b;
    breedSummary.innerHTML = `
      <div class="d-flex align-items-start gap-3">
        <div>
          <h4 class="mb-1">${b.name} <span class="badge bg-secondary">${b.species}</span></h4>
          <div><strong>Size:</strong> ${b.size}</div>
          <div><strong>Temperament:</strong> ${b.temperament}</div>
          <div><strong>Lifespan:</strong> ${b.lifespan}</div>
        </div>
      </div>`;

    feedingTips.innerHTML = `
      <ul class="mb-2">
        ${(b.feeding_tips || []).map(t => `<li>${t}</li>`).join('')}
      </ul>`;

    groomingExercise.innerHTML = `
      <div><strong>Exercise:</strong> ${b.exercise}</div>
      <div><strong>Grooming:</strong> ${b.grooming}</div>`;

    healthTips.innerHTML = `
      <ul class="mb-0">
        ${(b.health || []).map(h => `<li>${h}</li>`).join('')}
      </ul>`;

    // Auto-generate practical advice locally (no external AI call)
    aiAdvice.innerHTML = `<div class="p-3 bg-light rounded"><pre style="white-space:pre-wrap">${buildAdvice(b)}</pre></div>`;
  }

  // Compose simple, practical guidance using local breed data
  function buildAdvice(b) {
    const lines = [];
    lines.push(`Practical care recommendations for ${b.name} (${b.species})`);
    lines.push('');
    lines.push(`Diet: Focus on balanced, portion-controlled meals. For ${b.size.toLowerCase()} ${b.species.toLowerCase()}, adjust calories to maintain a healthy body condition. Avoid overfeeding and table scraps.`);
    if ((b.feeding_tips || []).length) {
      lines.push('Feeding tips:');
      for (const t of (b.feeding_tips || [])) lines.push(`- ${t}`);
    }
    lines.push('');
    lines.push(`Exercise: ${b.exercise}. Keep consistent daily activity suited to energy level and age.`);
    lines.push(`Grooming: ${b.grooming}. Check ears, nails, and coat regularly.`);
    if ((b.health || []).length) {
      lines.push('');
      lines.push('Common health considerations:');
      for (const h of (b.health || [])) lines.push(`- ${h}`);
      lines.push('If you notice urgent symptoms (severe lethargy, breathing issues, persistent vomiting/diarrhea), contact a veterinarian promptly.');
    }
    lines.push('');
    lines.push('General safety: Provide fresh water at all times, keep vaccines and parasite prevention up to date, and schedule routine vet check-ups.');
    return lines.join('\n');
  }

  identifyBtn.addEventListener('click', () => {
    let breed = null;
    // Try image-based match first
    const file = imageInput.files && imageInput.files[0];
    if (file) {
      breed = matchBreedFromFilename(file.name);
    }
    // Fallback to dropdown
    if (!breed && breedSelect.value) {
      breed = BREEDS.find(b => String(b.id) === String(breedSelect.value));
    }
    renderBreed(breed || null);
  });

  // AI Identify via Hugging Face
  async function aiIdentifyFromImage(file) {
    if (!file) return null;
    aiIdentifyStatus.textContent = 'Identifying via Hugging Face...';
    const fd = new FormData();
    fd.append('image', file);
    try {
      const res = await fetch('./api/hf_image.php', { method: 'POST', body: fd });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || 'HTTP ' + res.status);
      }
      const data = await res.json();
      // Normalize predictions to an array of {label, score}
      let preds = [];
      if (Array.isArray(data)) {
        if (data.length && Array.isArray(data[0])) preds = data[0]; else preds = data;
      }
      // map label to local BREEDS by name/alias fuzzy
      const toKey = s => (s || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
      function mapToBreed(label) {
        const lk = toKey(label);
        // exact-ish
        for (const b of BREEDS) {
          const names = [b.name, ...(b.aliases || [])];
          for (const n of names) {
            if (toKey(n) === lk) return b;
          }
        }
        // contains
        for (const b of BREEDS) {
          const names = [b.name, ...(b.aliases || [])];
          for (const n of names) {
            if (lk.includes(toKey(n))) return b;
          }
        }
        return null;
      }
      for (const p of preds) {
        const b = mapToBreed(p.label || p.class || '');
        if (b) {
          aiIdentifyStatus.textContent = `Top match: ${p.label} (${Math.round((p.score || 0)*100)}%).`;
          return b;
        }
      }
      aiIdentifyStatus.textContent = 'No close match to local breeds. You can still pick from the dropdown.';
      return null;
    } catch (e) {
      console.error('AI identify failed', e);
      aiIdentifyStatus.textContent = 'AI identify failed.';
      return null;
    }
  }

  aiIdentifyBtn && aiIdentifyBtn.addEventListener('click', async () => {
    const file = imageInput.files && imageInput.files[0];
    if (!file) {
      aiIdentifyStatus.textContent = 'Please choose an image first.';
      return;
    }
    const b = await aiIdentifyFromImage(file);
    renderBreed(b || null);
  });

  // Nutrition calculator
  function calcRER(kg) {
    if (!kg || kg <= 0) return 0;
    return 70 * Math.pow(kg, 0.75);
  }

  function lifeStageMultiplier(stage) {
    switch (stage) {
      case 'puppy':
      case 'kitten':
        return 2.5; // growth
      case 'senior':
        return 1.2; // reduced activity
      default:
        return 1.6; // typical adult maintenance
    }
  }

  calcCaloriesBtn.addEventListener('click', () => {
    const kg = parseFloat(petWeight.value);
    const stage = lifeStage.value;
    if (!kg || kg <= 0) {
      calorieResult.textContent = 'Enter a valid weight.';
      return;
    }
    const rer = calcRER(kg);
    const kcal = Math.round(rer * lifeStageMultiplier(stage));
    calorieResult.innerHTML = `<strong>Recommended daily calories:</strong> ~${kcal} kcal/day`;
  });

  // Reminders CRUD
  async function loadReminders() {
    try {
      const res = await fetch(remindersApi);
      const items = await res.json();
      renderReminders(items);
    } catch (e) {
      console.error('Failed to load reminders', e);
    }
  }

  function renderReminders(items) {
    remindersTableBody.innerHTML = '';
    (items || []).forEach(item => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${item.breed || '-'}</td>
        <td>${item.type}</td>
        <td>${item.frequency}</td>
        <td>${new Date(item.created).toLocaleString()}</td>
        <td>
          <button class="btn btn-sm btn-outline-danger" data-id="${item.id}">Delete</button>
        </td>`;
      tr.querySelector('button').addEventListener('click', async () => {
        await deleteReminder(item.id);
        await loadReminders();
      });
      remindersTableBody.appendChild(tr);
    });
  }

  async function addReminder() {
    if (!selectedBreed) {
      alert('Please identify a breed first.');
      return;
    }
    const payload = {
      breed: selectedBreed.name,
      type: reminderType.value,
      frequency: reminderFrequency.value,
      created: new Date().toISOString()
    };
    try {
      await fetch(remindersApi, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      await loadReminders();
    } catch (e) {
      console.error('Failed to add reminder', e);
    }
  }

  async function deleteReminder(id) {
    try {
      await fetch(`${remindersApi}?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
    } catch (e) {
      console.error('Failed to delete reminder', e);
    }
  }

  addReminderBtn.addEventListener('click', addReminder);

  // Hide Ask AI UI if present (feature removed in favor of local advice)
  if (askAiBtn) askAiBtn.style.display = 'none';
  if (aiQuestion) aiQuestion.closest('.mb-3') && (aiQuestion.closest('.mb-3').style.display = 'none');
  if (aiTextStatus) aiTextStatus.style.display = 'none';

  // Init
  loadBreeds().then(loadReminders);
})();
